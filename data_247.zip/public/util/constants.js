
export const mainServerAddress="http://dev.wsdevworld.com:9000";
// export const mainServerAddress='https://www.makemydata.com';
