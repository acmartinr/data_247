package models;

public class RegistrationCompleteRequest {

    private String token;

    public RegistrationCompleteRequest() {}

    public String getToken() { return token; }
    public void setToken( String token ) { this.token = token; }
}
