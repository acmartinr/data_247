package services.db.entity;

public class Lender {

    private int id;
    private String lender;

    public Lender() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getLender() { return lender; }
    public void setLender(String lender) { this.lender = lender; }

}
